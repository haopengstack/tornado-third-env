Request Fields
==============

These classes encapsulate a request parameters or fields and are suitable for
passing to :meth:`~urllib3.request.RequestMethods.request`.

.. automodule:: urllib3.fields

    .. autoclass:: RequestField
       :members:
