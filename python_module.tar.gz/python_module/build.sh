#!/bin/sh

python setup.py install

cd cmodule/common_log/c++_swig/
python setup.py install
cd ../../../

cd cmodule/censorwords/c++_swig
python setup.py install
cd ../../../
