#!/bin/sh


#+++++++++++++++++++++++++++++++++++++++
# @function: start build python ext_module named censorwords 
# @method: using swig to wrapper c++ censorwords library for python
# @author：yemd
# @datetime: 2014-03-13 16:10
#+++++++++++++++++++++++++++++++++++++++
cd censorwords
./build.sh
cd ..


cd DuomiSessionUtil
./build.sh
cd ..


cd common_log
./build.sh
cd ..



cp 
