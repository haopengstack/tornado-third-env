#!/bin/sh

#用swig自动生成*_wrapper.c文件
swig -python helloah.i

#生成目标文件，为生成动态文件做准备
gcc -fPIC -c helloah.c helloah_wrap.c \
	-I/usr/include/python2.7 \
	-I/usr/lib/python2.7/config

#将.a文件用于生成动态库
ld  -shared  helloah.o helloah_wrap.o libhelloa.a -o _hellott.so


