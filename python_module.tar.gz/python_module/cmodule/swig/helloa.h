#ifndef HELLOA_H

#define HELLOA_H

void hello(const char * string);

#endif
