#include<stdio.h>

void hello(const char *string)
{
	printf("hello %s\n",string);
}
