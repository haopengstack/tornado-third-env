#!/bin/sh

rm -rf helloa.o  libhelloa.a

gcc -fPIC -c helloa.c

ar -crs libhelloa.a helloa.o

cp helloa.o libhelloa.a helloah/

