#include "commonlog_macro.h"

std::string commonlog_macro_key = "common";

void set_log_key(const std::string key){
	if(key.size()){
		commonlog_macro_key = key;
	}else{
		commonlog_macro_key = "common";
	}
}
