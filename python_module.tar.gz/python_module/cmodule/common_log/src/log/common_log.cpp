/*
 * =====================================================================================
 *
 *       Filename:  common_log.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2011年08月25日
 *       Revision:  none
 *       Compiler:  g++
 *
 *         Author:  mao.chen@duomi.com
 *        Company:  caiyunzaixian
 *
 * =====================================================================================
 */
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include <stdint.h>
#include "common_log.h"

using namespace std;
static CLogger* g_logger = NULL;

extern "C"{
    int32_t InitLog(const char* errorLogPrefix, const char* programLogPrefix, const char* businessLogPrefix,
                  int logLevel, int logInterval, const char* key) {
        // common_log的init函数支持重入（不重新load config）,否则共享内存释放会有问题
        if (g_logger != NULL) {
            return 0;
        }
		
        g_logger = new CLogger();
        return g_logger->Init(errorLogPrefix, programLogPrefix, businessLogPrefix,
                              logLevel, logInterval, key);
    }

    int32_t ProcessLogRequest(const char* uri, const char* request) {
        return g_logger->ChangeLogLevel(uri, request);
    }

    int32_t ReleaseLog() {
		cerr<<"release g_logger......................."<<endl;
        if (g_logger) {
            delete g_logger;
            g_logger = NULL;
        }
        return 0;
    }

    CLogger* GetLogger() {
        return g_logger;
    }
} // end of extern "C" 


