#include <iostream>
#include <fstream>
#include <string>
#include <sys/time.h>
#include "logger.h"

using namespace::std;

int main(int argc,char **argv) {
    CLogger logger;
    if (logger.Init("errorLogPrefix", "programLogPrefix", "businessLogPrefix",
                  LOGDEBUG, LOG_INTERVAL_HOUR, "testkey") != 0) {
        return -1;
    }

    logger.ProgramLog(LOGDEBUG, "ErrorNum: %d, ErrorMessage: %s", 500, "内部错误");
    logger.ProgramLog(LOGINFO, "ErrorNum: %d, ErrorMessage: %s", 200, "成功");
    logger.ProgramLog(LOGWARN, "ErrorNum: %d, ErrorMessage: %s", 301, "重定向");
    logger.ProgramLog(LOGERROR, "ErrorNum: %d, ErrorMessage: %s", 404, "访问受限");
    logger.BusinessLog("ErrorNum: %d, ErrorMessage: %s", 404, "访问受限");
    
    logger.ChangeLogLevel("uri-nouse", "level=1&key=testkey");
    logger.ProgramLog(LOGDEBUG, "after call ChangeLogLevel(LOGINFO), ErrorNum: %d, ErrorMessage: %s", 500, "内部错误");
    logger.ProgramLog(LOGINFO, "after call ChangeLogLevel(LOGINFO), ErrorNum: %d, ErrorMessage: %s", 200, "成功");
    logger.ProgramLog(LOGWARN, "after call ChangeLogLevel(LOGINFO), ErrorNum: %d, ErrorMessage: %s", 301, "重定向");
    logger.ProgramLog(LOGERROR, "after call ChangeLogLevel(LOGINFO), ErrorNum: %d, ErrorMessage: %s", 404, "访问受限");
    logger.BusinessLog("ErrorNum: %d, ErrorMessage: %s", 404, "访问受限");


}

