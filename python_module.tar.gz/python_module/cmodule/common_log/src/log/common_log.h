/*
 * =====================================================================================
 *
 *       Filename:  common_log.h
 *
 *    Description:  nginx模块调用的接口
 *
 *        Version:  1.0
 *        Created:  2011年08月25日
 *       Revision:  none
 *       Compiler:  g++
 *
 *         Author:  mao.chen@duomi.com
 *        Company:  caiyunzaixian
 *
 * =====================================================================================
 */
#ifndef _DUOMI_COMMON_LOG_
#define _DUOMI_COMMON_LOG_
#include <stdint.h>
#include "logger.h"

extern "C"{

    CLogger* GetLogger();

    /*! @function ******************************************************************
    Name : InitLog
    Description : 初始化函数，读取配置文件
    Parameters :
       [IN] errorLogPrefix : 错误日志路径
       [IN] programLogPrefix : 程序日志路径
       [IN] businessLogPrefix : 业务日志路径
       [IN] logLevel : 日志级别(debug/info/warn/error)
       [IN] logInterval : 日志文件切分时间(hour/day/month/year)
       [IN] key : 日志级别修改所需的key
    Return : 正确返回0
    -------------------------------------------------------------------------------- 
    Remarks : 全局调用一次
    Usage : Init("/a8root/error", "/a8root/program", "/a8root/business", 
                      LOGDEBUG, LOG_INTERVAL_DAY, "test123")
    *******************************************************************************/
    int32_t InitLog(const char* errorLogPrefix, const char* programLogPrefix, const char* businessLogPrefix,
                             int logLevel, int logInterval, const char* key);

    /*! @function ******************************************************************
    Name : ProcessLogRequest
    Description : 处理http请求，修改log级别
    Parameters :
       [IN] uri : 服务的路径，目前没用上
       [IN] request : 请求的参数列表，需要包括:
                            level - int，范围定义在logger.h中
                            key - string，对应配置文件中的key
    Return : 正确返回0，并且会调整log到相应的级别
                 失败返回非0，log级别不会调整
    -------------------------------------------------------------------------------- 
    Remarks : 
    Usage : ProcessLogRequest("/common_log/", "level=1&key=test123")
    *******************************************************************************/
    int32_t ProcessLogRequest(const char* uri, const char* request);

    /*! @function ******************************************************************
    Name : ReleaseLog
    Description : 析构函数，释放内部资源
    Parameters :
        无
    Return : 正确返回0
    --------------------------------------------------------------------------------
    Remarks : 全局调用一次
    *******************************************************************************/
    int32_t ReleaseLog();
};

#endif
