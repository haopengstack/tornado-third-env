g++44 -g -D_FILE_OFFSET_BITS=64 -DDEBUG -D_REENTRANT -Wall -DDEBUG -lcurl -fprofile-arcs -ftest-coverage -o main main.cpp -L.libs/ -I/usr/local/include .libs/libcommon_log.a
