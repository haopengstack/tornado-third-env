#ifndef COMMONLOG_MACRO_H

#define COMMONLOG_MACRO_H
#include <string>




//#include <common_log/common_log.h>

//找时间用程序自动生成这个文件
//
//组合1
//
//
//std::string commonlog_macro_key = "common";
//
//
extern std::string commonlog_macro_key;

void set_log_key(const std::string key);



#ifdef DUOMILOGDEBUG 

#define DEBUG_LOG_S(s) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s",commonlog_macro_key.c_str(),s)

#define DEBUG_LOG_D(d) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld",commonlog_macro_key.c_str(),(int64_t)d)

#define DEBUG_LOG_SS(s1,s2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s",commonlog_macro_key.c_str(),s1,s2)
#define DEBUG_LOG_DD(d1,d2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2)
#define DEBUG_LOG_DS(d,s) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld:%s",commonlog_macro_key.c_str(),(int64_t)d,s)
#define DEBUG_LOG_SD(s,d) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld",commonlog_macro_key.c_str(),s,(int64_t)d)
#define DEBUG_LOG_SF(s1,f1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%f",commonlog_macro_key.c_str(),s1,f1)


#define DEBUG_LOG_SSS(s1,s2,s3) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3)
#define DEBUG_LOG_DDD(d1,d2,d3) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define DEBUG_LOG_SSD(s1,s2,d) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d)
#define DEBUG_LOG_SDS(s1,d,s2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%s",commonlog_macro_key.c_str(),s1,(int64_t)d,s2)
#define DEBUG_LOG_DSS(d,s1,s2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld:%s:%s",commonlog_macro_key.c_str(),(int64_t)d,s1,s2)
#define DEBUG_LOG_SDD(s,d1,d2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2)
#define DEBUG_LOG_DDS(d1,d2,s) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld:%lld:%s",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,s)
#define DEBUG_LOG_DSD(d1,s,d2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld:%s:%lld",commonlog_macro_key.c_str(),(int64_t)d1,s,(int64_t)d2)
#define DEBUG_LOG_SDF(s1,d1,f1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%d:%f",commonlog_macro_key.c_str(),s1,(int64_t)d1,f1)
#define DEBUG_LOG_SFD(s1,f1,d1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%f:%d",commonlog_macro_key.c_str(),s1,f1,(int64_t)d1)
#define DEBUG_LOG_SSF(s1,s2,f1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%f",commonlog_macro_key.c_str(),s1,s2,f1)

//组合4
#define DEBUG_LOG_SSSS(s1,s2,s3,s4) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3,s4)
#define DEBUG_LOG_SSSD(s1,s2,s3,d1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1)
#define DEBUG_LOG_SDSS(s1,d1,s2,s3) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%s:%s",commonlog_macro_key.c_str(),s1,(int64_t)d1,s2,s3)
#define DEBUG_LOG_SDSD(s1,d1,s2,d2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%s:%lld",commonlog_macro_key.c_str(),s1,(int64_t)d1,s2,(int64_t)d2)
#define DEBUG_LOG_SDDS(s1,d1,d2,s2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%lld:%s",commonlog_macro_key.c_str(),s1,(int64_t)d1,(int64_t)d2,s2)
#define DEBUG_LOG_SSDD(s1,s2,d1,d2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2)
#define DEBUG_LOG_SDDD(s,d1,d2,d3) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define DEBUG_LOG_DDDD(d1,d2,d3,d4) GetLogger()->ProgramLog(LOGDEBUG,"%s|%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define DEBUG_LOG_SSDS(s1,s2,d1,s3) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%lld:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,s3)
#define DEBUG_LOG_SSDF(s1,s2,d1,f1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%d:%f",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,f1)
#define DEBUG_LOG_SDDF(s1,d1,d2,f1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%d:%d:%f",commonlog_macro_key.c_str(),s1,(int64_t)d1,(int64_t)d2,f1)
#define DEBUG_LOG_SDFD(s1,d1,f1,d2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%d:%f:%d",commonlog_macro_key.c_str(),s1,(int64_t)d1,f1,(int64_t)d2)
#define DEBUG_LOG_SSSF(s1,s2,s3,f1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%.3f",commonlog_macro_key.c_str(),s1,s2,s3,f1)


//U表示打印无符号整型
#define DEBUG_LOG_SSDU(s1,s2,d1,u1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%lld:%llu",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(uint64_t)u1)
#define DEBUG_LOG_SDDU(s,d1,d2,u1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%lld:%llu",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2,(uint64_t)u1)


//组合5
#define DEBUG_LOG_SSSSS(s1,s2,s3,s4,s5) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3,s4,s5)
#define DEBUG_LOG_SSSDD(s1,s2,s3,d1,d2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1,(int64_t)d2)
#define DEBUG_LOG_SSSDS(s1,s2,s3,d1,s4) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%lld:%s",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1,s4)
#define DEBUG_LOG_SSSSD(s1,s2,s3,s4,d1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,s3,s4,(int64_t)d1)
#define DEBUG_LOG_SSDDD(s1,s2,d1,d2,d3) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define DEBUG_LOG_SDSDD(s1,d1,s2,d2,d3) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,(int64_t)d1,s2,(int64_t)d2,(int64_t)d3)
#define DEBUG_LOG_SDDDD(s1,d1,d2,d3,d4) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),s1,(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define DEBUG_LOG_SSDSS(s1,s2,d1,s3,s4) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%lld:%s:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,s3,s4)
#define DEBUG_LOG_SSSDF(s1,s2,s3,d1,f1) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%d:%f",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1,f1)
#define DEBUG_LOG_SSSFF(s1,s2,s3,f1,f2) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%s:%.3f:%.3f",commonlog_macro_key.c_str(),s1,s2,s3,f1,f2)

//组合6
#define DEBUG_LOG_SSDDDD(s1,s2,d1,d2,d3,d4) GetLogger()->ProgramLog(LOGDEBUG,"%s|%s:%s:%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)



#else

#define DEBUG_LOG_S(s) 

#define DEBUG_LOG_D(d) 

#define DEBUG_LOG_SS(s1,s2) 
#define DEBUG_LOG_DD(d1,d2) 
#define DEBUG_LOG_DS(d,s) 
#define DEBUG_LOG_SD(s,d) 
#define DEBUG_LOG_SF(s1,f1)

#define DEBUG_LOG_SSS(s1,s2,s3) 
#define DEBUG_LOG_DDD(d1,d2,d3) 
#define DEBUG_LOG_SSD(s1,s2,d) 
#define DEBUG_LOG_SDS(s1,d,s2) 
#define DEBUG_LOG_DSS(d,s1,s2) 
#define DEBUG_LOG_SDD(s,d1,d2) 
#define DEBUG_LOG_DDS(d1,d2,s) 
#define DEBUG_LOG_DSD(d1,s,d2) 
#define DEBUG_LOG_SDF(s1,d1,f1) 
#define DEBUG_LOG_SFD(s1,f1,d1) 
#define DEBUG_LOG_SSF(s1,s2,f1)

#define DEBUG_LOG_SSSS(s1,s2,s3,s4)
#define DEBUG_LOG_SSSD(s1,s2,s3,d1)
#define DEBUG_LOG_SDSS(s1,d1,s2,s3)
#define DEBUG_LOG_SDSD(s1,d1,s2,d2)
#define DEBUG_LOG_SSDD(s1,s2,d1,d2)
#define DEBUG_LOG_SDDD(s,d1,d2,d3)
#define DEBUG_LOG_DDDD(d1,d2,d3,d4)
#define DEBUG_LOG_SSDS(s1,s2,d1,s3)
#define DEBUG_LOG_SSDF(s1,s2,d1,f1) 
#define DEBUG_LOG_SDDF(s1,d1,d2,f1)
#define DEBUG_LOG_SDFD(s1,d1,f1,d2) 
#define DEBUG_LOG_SSSF(s1,s2,s3,f1) 

#define DEBUG_LOG_SSSSS(s1,s2,s3,s4,s5) 
#define DEBUG_LOG_SSSDD(s1,s2,s3,d1,d2)
#define DEBUG_LOG_SSSDS(s1,s2,s3,d1,s4)
#define DEBUG_LOG_SSSSD(s1,s2,s3,s4,d1)
#define DEBUG_LOG_SSDDD(s1,s2,d1,d2,d3)
#define DEBUG_LOG_SDDDD(s1,d1,d2,d3,d4)
#define DEBUG_LOG_SSDSS(s1,s2,d1,s3,s4)
#define DEBUG_LOG_SSSDF(s1,s2,s3,d1,f1)
#define DEBUG_LOG_SSSFF(s1,s2,s3,f1,f2) 


//组合6
#define DEBUG_LOG_SSDDDD(s1,s2,d1,d2,d3,d4)

#endif







#ifdef DUOMILOGINFO 

#define INFO_LOG_S(s) GetLogger()->ProgramLog(LOGINFO,"%s|%s",commonlog_macro_key.c_str(),s)

#define INFO_LOG_D(d) GetLogger()->ProgramLog(LOGINFO,"%s|%lld",commonlog_macro_key.c_str(),(int64_t)d)

#define INFO_LOG_SS(s1,s2) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s",commonlog_macro_key.c_str(),s1,s2)
#define INFO_LOG_DD(d1,d2) GetLogger()->ProgramLog(LOGINFO,"%s|%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2)
#define INFO_LOG_DS(d,s) GetLogger()->ProgramLog(LOGINFO,"%s|%lld:%s",commonlog_macro_key.c_str(),(int64_t)d,s)
#define INFO_LOG_SD(s,d) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%lld",commonlog_macro_key.c_str(),s,(int64_t)d)


#define INFO_LOG_SSS(s1,s2,s3) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3)
#define INFO_LOG_DDD(d1,d2,d3) GetLogger()->ProgramLog(LOGINFO,"%s|%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define INFO_LOG_SSD(s1,s2,d) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d)
#define INFO_LOG_SDS(s1,d,s2) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%lld:%s",commonlog_macro_key.c_str(),s1,(int64_t)d,s2)
#define INFO_LOG_DSS(d,s1,s2) GetLogger()->ProgramLog(LOGINFO,"%s|%lld:%s:%s",commonlog_macro_key.c_str(),(int64_t)d,s1,s2)
#define INFO_LOG_SDD(s,d1,d2) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2)
#define INFO_LOG_DDS(d1,d2,s) GetLogger()->ProgramLog(LOGINFO,"%s|%lld:%lld:%s",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,s)
#define INFO_LOG_DSD(d1,s,d2) GetLogger()->ProgramLog(LOGINFO,"%s|%lld:%s:%lld",commonlog_macro_key.c_str(),(int64_t)d1,s,(int64_t)d2)
#define INFO_LOG_SDF(s1,d1,f1) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%lld:%f",commonlog_macro_key.c_str(),s1,(int64_t)d1,f1)


//组合4
#define INFO_LOG_SSSS(s1,s2,s3,s4) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3,s4)
#define INFO_LOG_SDDD(s,d1,d2,d3) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define INFO_LOG_DDDD(d1,d2,d3,d4) GetLogger()->ProgramLog(LOGINFO,"%s|%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define INFO_LOG_SDSS(s1,d1,s2,s3) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%lld:%s:%s",commonlog_macro_key.c_str(),s1,(int64_t)d1,s2,s3)
#define INFO_LOG_SSDS(s1,s2,d1,s3) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,s3)
#define INFO_LOG_SSDF(s1,s2,d1,f1) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld:%f",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,f1)
#define INFO_LOG_SSDD(s1,s2,d1,d2) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2)
#define INFO_LOG_SDDS(s1,d1,d2,s2) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%lld:%lld:%s",commonlog_macro_key.c_str(),s1,(int64_t)d1,(int64_t)d2,s2)


//组合5
#define INFO_LOG_SSSDD(s1,s2,s3,d1,d2) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1,(int64_t)d2)
#define INFO_LOG_SSDDD(s1,s2,d1,d2,d3) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define INFO_LOG_SDDDD(s1,d1,d2,d3,d4) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld:%lld:%lld,%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define INFO_LOG_SSDSS(s1,s2,d1,s3,s4) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld:%s:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,s3,s4)
#define INFO_LOG_SSDDS(s1,s2,d1,d2,s3) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%lld:%lld:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,d2,s3)
#define INFO_LOG_SSSDF(s1,s2,s3,d1,f1) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%s:%lld:%f",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1,f1)
#define INFO_LOG_SSSSS(s1,s2,s3,s4,s5) GetLogger()->ProgramLog(LOGINFO,"%s|%s:%s:%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3,s4,s5)

#else

#define INFO_LOG_S(s) 

#define INFO_LOG_D(d) 

#define INFO_LOG_SS(s1,s2) 
#define INFO_LOG_DD(d1,d2) 
#define INFO_LOG_DS(d,s) 
#define INFO_LOG_SD(s,d) 


#define INFO_LOG_SSS(s1,s2,s3) 
#define INFO_LOG_DDD(d1,d2,d3) 
#define INFO_LOG_SSD(s1,s2,d) 
#define INFO_LOG_SDS(s1,d,s2) 
#define INFO_LOG_DSS(d,s1,s2) 
#define INFO_LOG_SDD(s,d1,d2) 
#define INFO_LOG_DDS(d1,d2,s) 
#define INFO_LOG_DSD(d1,s,d2) 
#define INFO_LOG_SDF(s1,d1,f1) 


#define INFO_LOG_SSSS(s1,s2,s3,s4)
#define INFO_LOG_SDDD(s,d1,d2,d3)
#define INFO_LOG_DDDD(d1,d2,d3,d4)
#define INFO_LOG_SDSS(s1,d1,s2,s3) 
#define INFO_LOG_SSDS(s1,s2,d1,s3)
#define INFO_LOG_SSDF(s1,s2,d1,f1) 


#define INFO_LOG_SSSDD(s1,s2,s3,d1,d2)
#define INFO_LOG_SSDDD(s1,s2,d1,d2,d3)
#define INFO_LOG_SDDDD(s1,d1,d2,d3,d4)
#define INFO_LOG_SSDSS(s1,s2,d1,s3,s4)
#define INFO_LOG_SSSDF(s1,s2,s3,d1,f1)
#define INFO_LOG_SSDD(s1,s2,d1,d2)
#define INFO_LOG_SSSSS(s1,s2,s3,s4,s5)

#endif











//log waring 
#define WARN_LOG_S(s) GetLogger()->ProgramLog(LOGWARN,"%s|%s",commonlog_macro_key.c_str(),s)

#define WARN_LOG_D(d) GetLogger()->ProgramLog(LOGWARN,"%s|%d",commonlog_macro_key.c_str(),(int64_t)d)

#define WARN_LOG_SS(s1,s2) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s",commonlog_macro_key.c_str(),s1,s2)
#define WARN_LOG_DD(d1,d2) GetLogger()->ProgramLog(LOGWARN,"%s|%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2)
#define WARN_LOG_DS(d,s) GetLogger()->ProgramLog(LOGWARN,"%s|%lld:%s",commonlog_macro_key.c_str(),(int64_t)d,s)
#define WARN_LOG_SD(s,d) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%lld",commonlog_macro_key.c_str(),s,(int64_t)d)

#define WARN_LOG_SSS(s1,s2,s3) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3)
#define WARN_LOG_DDD(d1,d2,d3) GetLogger()->ProgramLog(LOGWARN,"%s|%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define WARN_LOG_SSD(s1,s2,d) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d)
#define WARN_LOG_SDS(s1,d,s2) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%lld:%s",commonlog_macro_key.c_str(),s1,(int64_t)d,s2)
#define WARN_LOG_DSS(d,s1,s2) GetLogger()->ProgramLog(LOGWARN,"%s|%lld:%s:%s",commonlog_macro_key.c_str(),(int64_t)d,s1,s2)
#define WARN_LOG_SDD(s,d1,d2) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2)
#define WARN_LOG_DDS(d1,d2,s) GetLogger()->ProgramLog(LOGWARN,"%s|%lld:%lld:%s",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,s)
#define WARN_LOG_DSD(d1,s,d2) GetLogger()->ProgramLog(LOGWARN,"%s|%lld:%s:%lld",commonlog_macro_key.c_str(),(int64_t)d1,s,(int64_t)d2)


#define WARN_LOG_SSSS(s1,s2,s3,s4) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3,s4)
#define WARN_LOG_SSSD(s1,s2,s3,d1) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1)
#define WARN_LOG_SDDD(s,d1,d2,d3) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define WARN_LOG_DDDD(d1,d2,d3,d4) GetLogger()->ProgramLog(LOGWARN,"%s|%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define WARN_LOG_SSDS(s1,s2,d1,s3) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%lld:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,s3)
#define WARN_LOG_SSDD(s1,s2,d1,d2) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2)



#define WARN_LOG_SDDDD(s,d1,d2,d3,d4) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define WARN_LOG_SSSDD(s1,s2,s3,d1,d2) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1,(int64_t)d2)
#define WARN_LOG_SSDDD(s1,s2,d1,d2,d3) GetLogger()->ProgramLog(LOGWARN,"%s|%s:%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2,d3)










//log error
#define ERROR_LOG_S(s) GetLogger()->ProgramLog(LOGERROR,"%s|%s",commonlog_macro_key.c_str(),s)
#define ERROR_LOG_D(d) GetLogger()->ProgramLog(LOGERROR,"%s|%lld",commonlog_macro_key.c_str(),(int64_t)d)
#define ERROR_LOG_SS(s1,s2) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s",commonlog_macro_key.c_str(),s1,s2)
#define ERROR_LOG_DD(d1,d2) GetLogger()->ProgramLog(LOGERROR,"%s|%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2)
#define ERROR_LOG_DS(d,s) GetLogger()->ProgramLog(LOGERROR,"%s|%lld:%s",commonlog_macro_key.c_str(),(int64_t)d,s)
#define ERROR_LOG_SD(s,d) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%lld",commonlog_macro_key.c_str(),s,(int64_t)d)
#define ERROR_LOG_SSS(s1,s2,s3) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3)
#define ERROR_LOG_DDD(d1,d2,d3) GetLogger()->ProgramLog(LOGERROR,"%s|%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define ERROR_LOG_SSD(s1,s2,d) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d)
#define ERROR_LOG_SDS(s1,d,s2) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%lld:%s",commonlog_macro_key.c_str(),s1,(int64_t)d,s2)
#define ERROR_LOG_DSS(d,s1,s2) GetLogger()->ProgramLog(LOGERROR,"%s|%lld:%s:%s",commonlog_macro_key.c_str(),(int64_t)d,s1,s2)
#define ERROR_LOG_SDD(s,d1,d2) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2)
#define ERROR_LOG_DDS(d1,d2,s) GetLogger()->ProgramLog(LOGERROR,"%s|%lld:%lld:%s",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,s)
#define ERROR_LOG_DSD(d1,s,d2) GetLogger()->ProgramLog(LOGERROR,"%s|%lld:%s:%lld",commonlog_macro_key.c_str(),(int64_t)d1,s,(int64_t)d2)


#define ERROR_LOG_SSSS(s1,s2,s3,s4) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3,s4)
#define ERROR_LOG_SDDD(s,d1,d2,d3) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s,(int64_t)d1,(int64_t)d2,(int64_t)d3)
#define ERROR_LOG_DDDD(d1,d2,d3,d4) GetLogger()->ProgramLog(LOGERROR,"%s|%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define ERROR_LOG_SSDD(s1,s2,d1,d2) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(int64_t)d2)
#define ERROR_LOG_SSDS(s1,s2,d1,s3) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%lld:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,s3)
#define ERROR_LOG_SSSD(s1,s2,s3,d1) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1)

#define ERROR_LOG_SDSS(s1,d1,s2,s3) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%lld:%s:%s",commonlog_macro_key.c_str(),s1,(int64_t)d1,s2,s3)


#define ERROR_LOG_SDDDD(s1,d1,d2,d3,d4) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%lld:%lld:%lld:%lld",commonlog_macro_key.c_str(),s1,(int64_t)d1,(int64_t)d2,(int64_t)d3,(int64_t)d4)
#define ERROR_LOG_SSSDD(s1,s2,s3,d1,d2) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%s:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,s3,(int64_t)d1,(int64_t)d2)
#define ERROR_LOG_SSDDD(s1,s2,d1,d2,d3) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%lld:%lld:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(uint64_t)d2,(uint64_t)d3)
#define ERROR_LOG_SSDSD(s1,s2,d1,s3,d2) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%lld:%s:%lld",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,s3,(uint64_t)d2)
#define ERROR_LOG_SSDDS(s1,s2,d1,d2,s3) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%lld:%lld:%s",commonlog_macro_key.c_str(),s1,s2,(int64_t)d1,(uint64_t)d2,s3)
#define ERROR_LOG_SSSSD(s1,s2,s3,s4,d1) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%s:%s:%lld",commonlog_macro_key.c_str(),s1,s2,s3,s4,(int64_t)d1)
#define ERROR_LOG_SSSSS(s1,s2,s3,s4,s5) GetLogger()->ProgramLog(LOGERROR,"%s|%s:%s:%s:%s:%s",commonlog_macro_key.c_str(),s1,s2,s3,s4,s5)






#define BUSINESS_LOG_SS(s1,s2) GetLogger()->BusinessLog("%s|%s",\
		!s1?"-":s1,\
		!s2?"-":s2)

#define BUSINESS_LOG_SD(s1,d1) GetLogger()->BusinessLog("%s|%lld",\
		!s1?"-":s1,\
		(int64_t)d1)

//log business
//format:uid|ip|func|return_val|request_time|request|postcontent
#define BUSINESS_LOG_SSDS(s1,s2,d1,s3) GetLogger()->BusinessLog("%s|%s|%lld|%s",\
		!s1?"-":s1,\
		!s2?"-":s2,\
		(int64_t)d1,\
		!s3?"-":s3)

//get request businesslog print
//format:ip|funckey|uid|get_request|wastetime
#define BUSINESS_LOG_SSSD(ip,uid,s1,d1) GetLogger()->BusinessLog( \
		"%s|%s|%s|%s|%lld",\
		!ip?"-":ip,\
		commonlog_macro_key.c_str(),\
		!uid?"-":uid,\
		!s1?"-":s1,\
		(int64_t)d1)

//post request businesslog print
//format:ip|funckey|uid|wastetime|request ## postcontent
#define BUSINESS_LOG_SSDSS(ip,uid,d1,s1,s2) GetLogger()->BusinessLog( \
		"%s|%s|%s|%lld|%s ## %s",\
		!ip?"-":ip,\
		commonlog_macro_key.c_str(),\
		!uid?"-":uid,\
		(int64_t)d1,\
		!s1?"-":s1,\
		!s2?"-":s2)

//get request businesslog print
//format:ip|funckey|uid|return_code|wastetime|get_request
#define BUSINESS_LOG_SSDDS(ip,uid,d1,d2,s1) GetLogger()->BusinessLog( \
		"%s|%s|%s|%lld|%lld|%s",\
		!ip?"-":ip,\
		commonlog_macro_key.c_str(),\
		!uid?"-":uid,\
		(int64_t)d1,\
		(int64_t)d2,\
		!s1?"-":s1)

#define BUSINESS_LOG_SSDD(ip,uid,d1,d2) GetLogger()->BusinessLog( \
		"%s|%s|%s|%lld|%lld",\
		!ip?"-":ip,\
		commonlog_macro_key.c_str(),\
		!uid?"-":uid,\
		(int64_t)d1,\
		(int64_t)d2)

//post request businesslog print
//format:ip|funckey|uid|return_code|wastetime|post_request ## post_content
#define BUSINESS_LOG_SSDDSS(ip,uid,d1,d2,s1,s2) GetLogger()->BusinessLog( \
		"%s|%s|%s|%lld|%lld|%s ## %s",\
		!ip?"-":ip,\
		commonlog_macro_key.c_str(),\
		!uid?"-":uid,\
		(int64_t)d1,\
		(int64_t)d2,\
		!s1?"-":s1,\
		!s2?"-":s2)


//format:funckey|ip|uid|s1,s2,s3,s4,s5  //7 args 
#define BUSINESS_LOG_SSSSSSS(ip,uid,s1,s2,s3,s4,s5) GetLogger()->BusinessLog( \
		"%s|%s|%s|%s|%s|%s|%s|%s",\
		commonlog_macro_key.c_str(),\
		!ip?"-":ip,\
		!uid?"-":uid,\
		!s1?"-":s1,\
		!s2?"-":s2,\
		!s3?"-":s3,\
		!s4?"-":s4,\
		!s5?"-":s5)

#define BUSINESS_LOG_SSSSSSSD(ip,uid,s1,s2,s3,s4,s5,d1) GetLogger()->BusinessLog( \
		"%s|%s|%s|%s|%s|%s|%s|%s|%lld",\
		commonlog_macro_key.c_str(),\
		!ip?"-":ip,\
		!uid?"-":uid,\
		!s1?"-":s1,\
		!s2?"-":s2,\
		!s3?"-":s3,\
		!s4?"-":s4,\
		!s5?"-":s5,\
		(uint64_t)d1)



#define BUSINESS_LOG_DSS(id,s1,s2) GetLogger()->BusinessLog(\
		"%lld|%s|%s",\
		id,\
		s1,\
		s2)

//format :func|responsecode|request|post

#define BUSINESS_LOG_SDSS(func,code,request,post) GetLogger()->BusinessLog(\
		"%s|%d|%s|%s",\
		!func?"-":func,\
		code,\
		!request?"-":request,\
		!post?"-":post)

#define BUSINESS_LOG_SSSS(func,status,request,post) GetLogger()->BusinessLog(\
		"%s|%s|%s|%s",\
		!func?"-":func,\
		!status?"-":status,\
		!request?"-":request,\
		!post?"-":post)

#define BUSINESS_LOG_SSSSS(func,uid,request,onmsg,offmsg) GetLogger()->BusinessLog(\
		"%s|%s|%s|%s|%s",\
		!func?"-":func,\
		!uid?"-":uid,\
		!request?"-":request,\
		!onmsg?"-":onmsg,\
		!offmsg?"-":offmsg)

//for test
#define BUSINESS_LOG_SSSSSS(func,uid,request,onmsg,offmsg,s1) GetLogger()->BusinessLog(\
		"%s|%s|%s|%s|%s|%s",\
		!func?"-":func,\
		!uid?"-":uid,\
		!request?"-":request,\
		!onmsg?"-":onmsg,\
		!offmsg?"-":offmsg,\
		!s1?"-":s1)

#define TEST_INIT_LOG(path) InitLog(path,path,path,0,2,"test");
#define TEST_INIT_LOG_2(path_err,path_run) InitLog(path_err,path_run,path_run,0,2,"test");
#define TEST_RELEASE_LOG() ReleaseLog()


#define BUSINESS_LOG_DSDDSDSSDSSS(iret,func,time,sid,stype,tid,ttype,msgid,finishid,addition_content,devmd5,offline_content) \
	GetLogger()->BusinessLog(\
	  "%d|%s|time:%lld|%lld|%s|%lld|%s|%s|%lld|%s|%s|%s",\
	  iret,\
	  !func?"-":func,\
	  time, \
	  sid, \
	  !stype?"-":stype, \
	  tid, \
	  !ttype?"-":ttype, \
	  !msgid?"-":msgid, \
	  finishid, \
	  !addition_content?"-":addition_content, \
	  !devmd5?"-":devmd5, \
	  !offline_content?"-":offline_content);		


#define BUSINESS_LOG_DSDDSDSSDDSS(iret,func,time,sid,stype,tid,ttype,msgid,finishid,addition_content,devmd5,offline_content) \
	GetLogger()->BusinessLog(\
	  "%d|%s|time:%lld|%lld|%s|%lld|%s|%s|%lld|%lld|%s|%s",\
	  iret,\
	  !func?"-":func,\
	  time, \
	  sid, \
	  !stype?"-":stype, \
	  tid, \
	  !ttype?"-":ttype, \
	  !msgid?"-":msgid, \
	  finishid, \
	  addition_content, \
	  !devmd5?"-":devmd5, \
	  !offline_content?"-":offline_content);		



#endif /* end of include guard: COMMONLOG_MACRO_H */
