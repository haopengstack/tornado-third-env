/*
 * =====================================================================================
 *
 *       Filename:  logger.h
 *
 *    Description:  通用log类定义模块
 *
 *        Version:  1.0
 *        Created:  2011年08月25日
 *       Revision:  none
 *       Compiler:  g++
 *
 *         Author:  mao.chen@duomi.com
 *        Company:  caiyunzaixian
 *
 * =====================================================================================
 */

#ifndef _DUOMI_TYPE_CONVERTER_UTIL__
#define _DUOMI_TYPE_CONVERTER_UTIL__

#include <string>

class CTypeConverter{
public:
    /*! @function ******************************************************************
    Name : TimeToStr
    Description :将时间结构体转换成string形式
    Parameters :
        [IN] t : 时间结构体
        [OUT] buf : 格式转换后的string
                         调用者必须保证buf足够大，目前的实现是需要20个char
    Return : None
    -------------------------------------------------------------------------------- 
    Remarks : 返回的buf内容例如: 2011/8/28 23:40:12
    Usage : TimeToStr(t, buf);
    *******************************************************************************/
    static void TimeToStr(const struct tm& t, char *buf);

    /*! @function ******************************************************************
    Name : IntToStr
    Description :整数到字符串的转换
    Parameters :
        [IN] value: 待转换的整数值
    Return : 转换后的字符串值
    -------------------------------------------------------------------------------- 
    Remarks :
    Usage : IntToStr(123);
    *******************************************************************************/
    static std::string IntToStr(int value);
    
    /*! @function ******************************************************************
    Name : StrToInt
    Description :字符串到整数的转换
    Parameters :
        [IN] str: 待转换的字符串
        [OUT] value: 转换后的整数值
    Return : 成功返回0
    -------------------------------------------------------------------------------- 
    Remarks : 转换
    Usage : StrToInt("123");
    *******************************************************************************/
    static int StrToInt(const std::string& str, int& value);
};
#endif
