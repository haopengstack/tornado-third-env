#include <stdio.h>
#include <stdarg.h>
#include <unistd.h>
#include <fcntl.h>
#include <sstream>

#include "type_converter.h"

using namespace std;

string CTypeConverter::IntToStr(int value) {
    stringstream sstream;
    sstream << value;
    string ret;
    sstream >> ret;

    return ret;
}

int CTypeConverter::StrToInt(const string& str, int& value) {
    stringstream sstream;
    sstream << str;
    int ret;
    sstream >> ret;
    if (!sstream.fail()) {
        value = ret;
        return 0;
    }

    return -1;
}

void CTypeConverter::TimeToStr(const struct tm& ts, char *buf) {
    sprintf(buf, "%04d/%02d/%02d %02d:%02d:%02d",
            ts.tm_year+1900, ts.tm_mon+1, ts.tm_mday, ts.tm_hour, ts.tm_min, ts.tm_sec);
}

