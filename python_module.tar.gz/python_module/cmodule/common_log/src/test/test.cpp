/*
 * =====================================================================================
 *
 *       Filename:  image_control_interface.cpp
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  2011年07月21日
 *       Revision:  none
 *       Compiler:  g++
 *
 *         Author:  mao.chen@duomi.com
 *        Company:  caiyunzaixian
 *
 * =====================================================================================
 */
#include <iostream>
#include <fstream>
#include <string>
#include <sstream>
#include "common_log.h"

using namespace std;

extern "C"{
int process_test() {
    CLogger* logger = GetLogger();

    logger->ProgramLog(LOGDEBUG, "%s:%d, ErrorNum: %d, ErrorMessage: %s", __FILE__, __LINE__, 500, "debug");
    logger->ProgramLog(LOGINFO, "ErrorNum: %d, ErrorMessage: %s", 500, "info");
    logger->ProgramLog(LOGWARN, "ErrorNum: %d, ErrorMessage: %s", 500, "warn");
    logger->ProgramLog(LOGERROR, "ErrorNum: %d, ErrorMessage: %s", 500, "error");
    logger->BusinessLog("ErrorNum: %d, ErrorMessage: %s", 500, "business");

    return 0;
}
} // end of extern "C" 
