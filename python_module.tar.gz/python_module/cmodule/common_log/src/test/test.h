/*
 * =====================================================================================
 *
 *       Filename:  test.h
 *
 *    Description:  nginx模块调用的接口
 *
 *        Version:  1.0
 *        Created:  2011年07月21日
 *       Revision:  none
 *       Compiler:  g++
 *
 *         Author:  mao.chen@duomi.com
 *        Company:  caiyunzaixian
 *
 * =====================================================================================
 */
#ifndef _DUOMI_IMAGE_CONTROL_INTERFACE_
#define _DUOMI_IMAGE_CONTROL_INTERFACE_

#include "image.h"
#include "HTTPClient.h"
#include "http_get_parameter_parser.h"

extern "C"{
    int32_t process_test();
};

#endif
