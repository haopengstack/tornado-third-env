#-*- coding: utf-8 -*-
#!/usr/bin/python

import common_log

print dir(common_log)

#print dir(common_log.Clogger)

#uid = common_log.getDuomiUidFromSession(session,len(session))
#print uid,type(uid)

retnum = common_log.InitLog('error','program','business',0,1,'test')
print retnum,type(retnum)

logger = common_log.GetLogger()
print dir(logger)

logger.ProgramLog(common_log.LOGDEBUG,"start----------------------------------")

a = "suc"
logger.ProgramLog(common_log.LOGDEBUG,"ErrorNum:%d, ErrorMsg:%s"%(200,"suc"))
logger.ProgramLog(common_log.LOGINFO,"ErrorNum:%d, ErrorMsg:%s"%(100,"info"))
logger.ProgramLog(common_log.LOGWARN,"ErrorNum:%d, ErrorMsg:%s"%(300,"warn"))
logger.ProgramLog(common_log.LOGERROR,"ErrorNum:%d, ErrorMsg:%s"%(404,"error"))

logger.BusinessLog("request:%s"%("ddddddddddddd"))


#释放空间
common_log.ReleaseLog()

