#!/bin/sh


echo "++++++++++++start common_log Makefile building+++++++++++++"
cd src/log
make clean
make
cd ../..

echo "++++++++++++start common_log ext_module building++++++++++++"
cd c++_swig
./build.sh
sudo python setup.py bdist_rpm

cd ../



