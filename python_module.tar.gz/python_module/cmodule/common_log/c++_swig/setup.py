#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: yemd
# FILENAME: setup.py
# CREATED: 2014-03-13 14:54
# MODIFIED: 2014-05-19 18:15
# Description: 


from distutils.core import setup,Extension

VERSION = '0.1'

common_log_module = Extension('_common_log',  
            include_dirs = ['/usr/include/python2.7',
            '/usr/lib/python2.7/config'],
            libraries = ['common_log'],
            library_dirs = ['./'],
            swig_opts=['-c++','-shadow'],
            sources=['common_log.i']
)  


setup(name='py_common_log',
      version=VERSION,
      author='DUOMI_PLATFORM',
      author_email='platform@duomi.com',
      url='http://www.duomi.com',
      download_url='www.duomi.com',
      description='common_log extend package for duomi_service',
      license='MIT',
      long_description='',
      ext_modules = [common_log_module],  
      py_modules = ["common_log"], 
      package_data={'test': ['build.sh']},
      classifiers=[
        'Development Status :: 1 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries',
      ]
)
