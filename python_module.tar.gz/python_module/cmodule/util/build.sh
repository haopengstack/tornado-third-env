#!/bin/sh

##++++++++++++++++++++++NOTE+++++++++++++++++++++++
##  执行此脚本前,请确认本台机器已经生成多米的第三方公用库.
##  即：
##     * thirdpartylib路径: svn://192.168.200.186/svnprojects/thirdpartylib
##     * 进入thirdpartylib, 执行sudo ./build.sh即可 
##++++++++++++++++++++++++++++++++++++++++++++++++++


#获取多米utility公用库
#if [ $# -lt 1 ]; then
#    echo "./shell-bin 0|1[0:inner_net|1:outer_net]"
#    exit 1
#fi


./check.sh



if [ ! -d m4 ]; then
	mkdir m4
fi
if [ -f Makefile ]; then
	make distclean
fi
make -f Makefile.cvs 

cd common_log/log
make && make install
cd ../../
cd common_log/test
make && make install
cd ../../

make && make install



