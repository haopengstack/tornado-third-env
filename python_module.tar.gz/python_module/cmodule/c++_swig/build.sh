#!/bin/sh

#直接使用distutils.core打包生成python扩展包
python setup.py build_ext --inplace
exit 0



#swig方式编译生成的python c++扩展包
rm -rf *.o *.so *.cxx

#用swig自动生成*_wrapper.c文件
swig -c++ -python -shadow test_module.i

#生成目标文件，为生成动态文件做准备
g++ -fPIC -c test_module.cpp test_module_wrap.cxx \
	-I/usr/include/python2.7 \
	-I/usr/lib/python2.7/config

#将.a文件用于生成动态库
#ld  -shared  censorwords.o censorwords_wrap.o libcensorinterface.a -o _censorwords.so
#c++封装且使用到标准c++库，编译和链接时候一定要带上-lstdc++
g++ -shared test_module.o test_module_wrap.o -o _TestModule.so -lstdc++


