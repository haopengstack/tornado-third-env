import sys
import TestModule

print dir(TestModule)


n = TestModule.TestModule()
print type(n)
print dir(n)
print n.thisown

res = n.initTestModule("filename")
print type(res)
print dir(res)


"""
n = TestModule.Number(5)
print type(n)
print dir(n)
n.add(5)
n.display()
"""


