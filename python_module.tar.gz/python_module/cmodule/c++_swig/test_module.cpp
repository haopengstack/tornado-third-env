#include "test_module.h"
using namespace std;

/*
Number::Number(int start) {
    data = start;
    cout<<"Number::"<<data<<endl;
}

Number::~Number() {
    cout<<"~Number::"<<data<<endl;
}

void Number::add(int value) {
    data += value;
    cout<<"add::"<<value<<endl;
}

void Number::sub(int value) {
    data -= value;
    cout<<"sub::"<<value<<endl;
}

void Number::display() {
    cout<<"Number::"<<data<<endl;
}
*/





TestModule::TestModule():_s("test_str") {
    cout<<"TestModule() start"<<_s<<endl;
}

int32_t TestModule::initTestModule(const char *config) {
	cout<<"initTestModule::start-------------------"<<endl;
    cout<<_s<<endl;
	return 0;
}


/*
class TestModule {
public:
    TestModule();
    int32_t initTestModule(const char *config);
};
*/
