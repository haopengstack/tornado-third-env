from distutils.core import setup, Extension

TestModule_module = Extension('_TestModule',
                    sources = ['test_module_wrap.cxx','test_module.cpp'])

setup (name = 'TestModule',
       version = '1.0',
       description = 'This is a demo package',
       ext_modules = [TestModule_module],
       py_modules = ["TestModule"],
	   )
