#include <iostream>
#include <string>
#include <stdint.h>

/*
class Number {

public:
	Number(int start);

	~Number();

	void add(int value);

	void sub(int value);

	void display();

	int data;
};*/


class TestModule {

public:
	TestModule();
	int32_t initTestModule(const char *config);
private:
    std::string _s;

};


