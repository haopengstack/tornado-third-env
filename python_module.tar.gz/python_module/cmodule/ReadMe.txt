编译查看工具：nm

查看具体符号代表的意思，使用nm -C *.o 或者 nm -C *.so

就能将编译内容查看清楚,特别是当出现symbol undefined的时候
