#!/bin/sh


#++++++++++++++++++++++++++++++++++++++++++++++++++++
# 以下为使用python distutils方式编译，
# 安装完毕之后将安装到/usr/local/python2.7/dist-packages目录下 
#++++++++++++++++++++++++++++++++++++++++++++++++++++
#rm -rf *.o *.so 

#用swig自动生成*_wrapper.c文件
#swig -c++ -python -shadow censorwords.i

#build_ext仅是测试是否能够成功编译？？？？
python setup.py build_ext --inplace
#能够一步到位解决所有安装问题:包含了build build_py build_ext install_lib所有步骤 
sudo python setup.py install 
exit 0


#++++++++++++++++++++++++++++++++++++++++++++++++++++
# 以下为使用swig方式编译，仅本目录下可以执行此扩展包 
#++++++++++++++++++++++++++++++++++++++++++++++++++++
rm -rf *.o *.so 

#用swig自动生成*_wrapper.c文件
#swig -c++ -python -shadow censorwords.i

#生成目标文件，为生成动态文件做准备
g++ -fPIC -c 97censorwords_wrap.cxx \
	-I/usr/local/python27/include/python2.7/ \
	-I/usr/lib/python2.7/

#将.a文件用于生成动态库
gcc -shared 97censorwords_wrap.o libcensorwords.a -o _censorwords.so -lstdc++


