#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: yemd
# FILENAME: setup.py
# CREATED: 2014-03-13 14:54
# MODIFIED: 2014-02-13 14:54
# Description: 


from distutils.core import setup,Extension
import sys

VERSION = '0.1'


censorwords_module = Extension('_censorwords',  
						include_dirs = ['/usr/include/python2.7',
										'/usr/lib/python2.7/config'],
						libraries = ['censorwords'],
						library_dirs = ['./'],
                        sources=['censorwords_wrap.cxx'],  
                           )  

setup(name='censorwords',
	  version=VERSION,
      author='DUOMI_PLATFORM',
      author_email='platform@duomi.com',
      url='http://www.duomi.com',
	  download_url='www.duomi.com',
      description='censorwords extend package for duomi_service',
	  license='MIT',
      long_description='',
      ext_modules = [censorwords_module],  
      py_modules = ["censorwords"], 
	  #package_dir=pkgdir,
	  #packages=['censorwords',
	  #			'censorwords.c++_swig'],
	  #package_data={'httplib2': ['*.txt']},
      classifiers=[
        'Development Status :: 1 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries',
        ],
        )
