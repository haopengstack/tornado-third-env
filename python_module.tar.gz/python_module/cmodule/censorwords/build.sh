#!/bin/sh


if [ ! -d src ];then
	echo 'start check co censorwords'
	svn co svn://192.168.200.186/svnprojects/utility/censorwords src
else
	echo "censorwords exist,start check newest version"
	cd src
	svn up
	cd ../
fi

echo "++++++++++++start censorwords Makefile building+++++++++++++"
cd src
cp py-Makefile Makefile
make clean
make
cd ..

echo "++++++++++++start censorwords ext_module building++++++++++++"
cd c++_swig
./build.sh
cd ../
