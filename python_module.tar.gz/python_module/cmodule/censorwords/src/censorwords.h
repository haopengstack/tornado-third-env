/*
 * C/C++ HEADER FILE
 * AUTHOR:   guangling.hou@gmail.com
 * FILENAME: censorwords.h
 * CREATED:  19:04:52 11/10/2012
 * MODIFIED: 19:59:24 18/10/2012
 */


#include <string>
#include <vector>
#include <map>
#include <stdint.h>
#include <memory.h>
#include <exception>
#include <stdexcept>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/time.h>
#include <dirent.h>
#include <iostream>
//#include <common_log/common_log.h>
//#include <common_log/commonlog_macro.h>

const int32_t MAXBUFFERSIZE = 800;

typedef struct acsm_struct ACSM_STRUCT;

class CensorChecker{

public:

	CensorChecker():_ACM(NULL){}	
	
	~CensorChecker(){
		releaseCensorWords();
	}

	int32_t initCensorWords(const char *config);

	int32_t censorReplace(
			const std::string &input,
			std::string &output);

	//int32_t censorCheck(const std::string &input);
	int32_t censorCheck(const char *input,const int32_t len);

	int32_t releaseCensorWords();

private:

	CensorChecker(const CensorChecker &){}

	const CensorChecker &operator=(const CensorChecker &){
		return *this;
	}

	
	char _rbuff[MAXBUFFERSIZE];

	ACSM_STRUCT *_ACM; 

};




