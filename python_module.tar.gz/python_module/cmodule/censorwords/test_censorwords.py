#!/usr/bin//python
#-- coding:utf-8 ----
import sys
import censorwords

print dir(censorwords)

#1.构建类
c = censorwords.CensorChecker()
print c
print type(c)
print dir(c)


#2.初始化
iret = c.initCensorWords("./censorwords.txt")
print iret
print type(iret)
if iret<0:
	print 'error initCensorWords'
	exit(-1)


#3.校验敏感词
input = "dsds_fuck"
ilen = len(input)
print type(input),input
print type(ilen),ilen

print "+++++++++++++++++++++++++++++++++++++="
result = "";
iret = c.censorCheck(input,ilen);
print iret
print type(iret)
if iret<0:
	print 'error censorCheck'
	exit(-1)

exit(0)


#此构造类析构函数自动释放，即__del__自动执行析构函数
#重复执行报double free error
"""
iret = c.releaseCensorWords()
print iret
print type(iret)
"""
