#!/bin/sh

gcc -g -Wall -o test main.c -I./include -L./lib \
	./lib/libcensorinterface.a \
	./lib/libcensorwords.a -lstdc++

