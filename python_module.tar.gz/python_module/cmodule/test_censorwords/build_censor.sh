#!/bin/sh


gcc -shared -o interface.so wrapper.o interface.o censorwords.o utf8string.o acsmx.o 

exit 0

rm -rf interface.o  wrapper.o interface.so

gcc -fpic -c wrapper.c interface.cpp \
			-I./include -L./lib ./lib/libcensorwords.a \
			-I/usr/lib/python2.7/config \
			-I/usr/include/python2.7 \
			-lstdc++

gcc -shared -o interface.so interface.o wrapper.o

exit 0

gcc -fpic -c interface.cpp \
	-I./include -L./lib ./lib/libcensorwords.a \
	-I/usr/include/python2.7 \
    -I/usr/lib/python2.7/config \
	-lstdc++

#gcc -shared -o example.so example.o wrapper.o



#g++ -fPIC -shared -o censor_extending.so censor_extending.cpp \
#	-I/usr/include/python2.7 \
#	-I./include -L./lib \
#	./lib/libcensorinterface.a \
#	./lib/libcensorwords.a \
#	-lboost_python-mt-py27 -lstdc++


