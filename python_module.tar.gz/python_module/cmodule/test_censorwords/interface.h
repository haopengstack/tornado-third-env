#ifndef _CENSORWORDS_INTERFACE_H_

#define _CENSORWORDS_INTERFACE_H_


#include <stdint.h>

#ifdef __cplusplus
extern "C"{
#endif

	extern int32_t initialize(const char *config);

	extern int32_t checkcensor(const char *str,const int32_t len);

	extern int32_t release();

#ifdef __cplusplus
};
#endif

#endif /* end of include guard: _CENSORWORDS_INTERFACE_H_ */
