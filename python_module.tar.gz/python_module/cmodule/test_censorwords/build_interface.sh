#!/bin/sh

g++ -fPIC -shared -o interface.so interface.cpp \
	-I./include -L./lib \
	./lib/libcensorwords.a \
	-lstdc++

