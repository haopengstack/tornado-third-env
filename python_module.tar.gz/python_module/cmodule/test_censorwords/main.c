#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <censorwords/interface.h>

int32_t main() {

	int32_t iret = 0;
	char file[256] = "./words.txt";
	char str[256] = "范德萨粉色打开";

	do {
		if (initialize(file) < 0) {
			fprintf(stderr,"initialize error\n");
			iret = -1;
			break;
		}

		iret = checkcensor(str,strlen(str));
		fprintf(stderr,"iret=%d\n",iret);
		if (iret < 0) {
			fprintf(stderr,"censorwords check error\n");
			iret = -1;
			break;
		} else if (iret > 0) {
			fprintf(stderr,"exist censorwords\n");
			iret = -1;
			break;
		} else {
			fprintf(stderr,"OK!\n");
			iret = 0;
			break;
		}
	}while(0);

	release();

	return 0;
}

