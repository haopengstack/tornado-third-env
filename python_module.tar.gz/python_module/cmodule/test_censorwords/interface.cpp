#include <iostream>
#include <string>
#include "censorwords/censorwords.h"
#include "interface.h"

using namespace std;

CensorChecker *checker = NULL;

extern "C"{

int32_t initialize(const char *config) {

	if (!config) {
		cerr<<"config is null"<<endl;
		return -1;
	}

	if (checker) {
		delete checker;
		checker = NULL;
	}

	checker = new CensorChecker();
	if (checker->initCensorWords(config) < 0) {
		cerr<<"init censorwords error"<<endl;
		return -1;
	}
	
	return 0;
}

/*
 * 返回：=0 不存在敏感词
 *		 >0 存在敏感词
 *		 <0 失败
 */
int32_t checkcensor(const char *str,const int32_t len) {
		
	if (!checker) {
		cerr<<"init error!!!!"<<endl;
		return -1;
	}

	if (!str || !len) {
		cerr<<"check str is empty"<<endl;
		return -1;
	}

	string content(str,len);
	string res;
	if (checker->censorReplace(content,res) < 0) {
		cerr<<"check censorwords error"<<endl;
		return -1;
	}

	if (content != res) {
		cerr<<"exist censor words"<<endl;
		return 1;
	}

	return 0;
}

int32_t release() {
	if (checker) {
		delete checker;
		checker = NULL;
	}
	return 0;
}

}; /*end of extern C*/
