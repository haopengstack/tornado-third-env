#!/bin/sh


#rm -rf *.o *.so *.cxx

#用swig自动生成*_wrapper.c文件
#swig -c++ -python -shadow censorwords.i

#build_ext仅是测试是否能够成功编译？？？？
#python setup.py build_ext --inplace
#能够一步到位解决所有安装问题:包含了build build_py build_ext install_lib所有步骤 
#python setup.py install 
#exit 0


rm -rf *.o *.so *.cxx

#用swig自动生成*_wrapper.c文件
swig -c++ -python -shadow censorwords.i

#生成目标文件，为生成动态文件做准备
g++ -fPIC -c censorwords_wrap.cxx \
	-I/usr/include/python2.7 \
	-I/usr/lib/python2.7/config

#将.a文件用于生成动态库
gcc -shared censorwords_wrap.o libcensorwords.a -o _censorwords.so -lstdc++


