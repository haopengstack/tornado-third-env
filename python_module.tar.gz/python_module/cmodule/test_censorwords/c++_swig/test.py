#!/usr/bin//python
#-- coding:utf-8 ----
import sys
import censorwords

print dir(censorwords)

#构建
c = censorwords.CensorChecker()
print c
print type(c)
print dir(c)

#初始化
iret = c.initCensorWords('./words.txt')
print iret
print type(iret)
if iret<0:
	print 'init censorwords error'
	exit(-1)


#校验敏感词
input = "dsds_fuck"
ilen = len(input)
print type(input),input
print type(ilen),ilen

print "+++++++++++++++++++++++++++++++++++++="
result = "";
iret = c.censorCheck(input,ilen);
print iret
print type(iret)
if iret<0:
	print 'censor check error'
	exit(-1)

exit(0)

#此构造类析构函数自动释放，即__del__自动执行析构函数

"""
iret = c.releaseCensorWords()
print iret
print type(iret)
"""
