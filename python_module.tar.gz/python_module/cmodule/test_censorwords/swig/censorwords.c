#include "interface.h"
int32_t new_initialize(const char *config) {
	return initialize(config);
}

/*
int32_t new_checkcensor(const char *str,const uint32_t len) {
	return checkcensor(str,len);
}

int32_t new_release() {
	return release();
}*/
