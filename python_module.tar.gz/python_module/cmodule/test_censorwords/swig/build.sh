#!/bin/sh

#用swig自动生成*_wrapper.c文件
swig -python censorwords.i

#生成目标文件，为生成动态文件做准备
gcc -fPIC -c censorwords.c censorwords_wrap.c \
	-I/usr/include/python2.7 \
	-I/usr/lib/python2.7/config

#将.a文件用于生成动态库
#ld 为solaris系统编译动态库的方式
#ld  -shared  censorwords.o censorwords_wrap.o libcensorinterface.a -o _censorwords.so

#unix/linux方式
gcc  -shared  censorwords.o censorwords_wrap.o libcensorinterface.a -o _censorwords.so -lstdc++


