#!/usr/bin/python
# -*- coding: utf-8 -*-
import _censorwords

print dir(_censorwords)

c = _censorwords.initialize('./words.txt')
print c
print type(c)
print dir(c)


print('checkcensor-------------------------------------')
content="fdsfkfuck"
c = _censorwords.checkcensor(content,len(content))
print c
print type(c)
print dir(c)


print('release-------------------------------------')
c = _censorwords.release()
print c
print type(c)
print dir(c)
