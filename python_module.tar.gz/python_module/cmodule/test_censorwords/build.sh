#!/bin/sh

bjam --preserve-test-targets

