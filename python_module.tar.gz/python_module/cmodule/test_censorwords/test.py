# -*- coding: utf-8 -*-
#!/usr/bin/python  

import interface

"""
from ctypes import *  
  
myso = cdll.LoadLibrary('./censorinterface.so')  
  
print dir(myso)
"""


"""
myso.say()  
  
add = myso.add  
add.argtypes = [c_int, c_int]     
add.restype = c_int               
  
print add(2,3)  
"""

