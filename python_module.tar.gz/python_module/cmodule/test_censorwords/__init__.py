#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: yemd
# FILENAME: __init__.py
# CREATED: 2014-03-13 11:21
# MODIFIED: 2014-03-13 11:21
# Description: 


#from c++_swig import censorwords


#__all__ = ["censorwords"]



