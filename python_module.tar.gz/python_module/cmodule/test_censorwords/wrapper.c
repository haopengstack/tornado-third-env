#include <Python.h>

//导出函数
PyObject* wrap_initialize(PyObject* self, PyObject* args) 
{
  int result;
  char *f = NULL;
  
  //解析args参数
  if (! PyArg_ParseTuple(args, "s:initialize", f))
    return NULL;

  //执行C模块代码
  result = initialize(f);

  //返回PyObject指针
  return Py_BuildValue("i", result);
}


//方法函数:给出所有可以给python解释器使用的方法
static PyMethodDef interfaceMethods[] = 
{
  {"initialize", wrap_initialize, METH_VARARGS, "initialize CensorWords!"},
  {NULL, NULL}
};

//初始化函数:init+模块名
void initinteface() 
{
  PyObject* m;
  m = Py_InitModule("interface", interfaceMethods);
}


