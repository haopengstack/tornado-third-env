#!/bin/sh

svn co svn://192.168.200.186/svnprojects/utility/censorwords

