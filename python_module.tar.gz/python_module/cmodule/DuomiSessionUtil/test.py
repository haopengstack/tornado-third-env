#!/usr/bin/python

import DuomiSessionUtil

print dir(DuomiSessionUtil)

session="1mRJBADJei10A9bHi1qS2h"
print session,type(session)

uid = DuomiSessionUtil.getDuomiUidFromSession(session,len(session))
print uid,type(uid)

