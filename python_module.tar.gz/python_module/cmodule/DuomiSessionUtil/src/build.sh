g++ -fPIC -g -o TestSessionUtil TestSessionUtil.cpp SessionUtil.cpp \
		-I/usr/local/include \
		-L/usr/local/lib \
		/usr/local/lib/libssl.a \
		-lstdc++ 
