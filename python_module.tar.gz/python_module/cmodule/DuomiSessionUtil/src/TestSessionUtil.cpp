#include <string>
#include <vector>
#include <map>
#include <stdint.h>
#include <memory.h>
#include <exception>
#include <stdexcept>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/time.h>
#include <dirent.h>
#include <iostream>
#include "SessionUtil.h"

using namespace std;


int main(int argc, const char *argv[])
{
	
	//string session = "02dNAwfJauo76noyv2SxZO";
	string session = "1mRJBADJei10A9bHi1qS2h";
	int32_t uid = getDuomiUidFromSession(session.c_str(),session.size());
	
	cout<<session<<endl;
	cout<<uid<<endl;
	return 0;
}
