#ifndef SESSIONUTIL_H


#define SESSIONUTIL_H


#include <string>
#include <vector>
#include <map>
#include <stdint.h>
#include <memory.h>
#include <exception>
#include <stdexcept>
#include <unistd.h>
#include <sys/wait.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/time.h>
#include <dirent.h>
#include <iostream>
#include <openssl/rc4.h>
#include <stdlib.h>
#include <sstream>


//为了能够返回符合python函数返回规则,直接返回uid
//返回uid内容
//uid<=0 说明解析发生错误，失败
//uid>0  解析成功
int32_t getDuomiUidFromSession(const char *session,const int32_t len);
	

/*int32_t getDuomiUidFromSession(
		const std::string &session,
		std::string &uid);
*/



#endif /* end of include guard: SESSIONUTIL_H */
