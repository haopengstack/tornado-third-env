#!/bin/sh


#++++++++++++++++++++++++++++++++++++++++++++++++++++
# 以下为使用python distutils方式编译，
# 安装完毕之后将安装到/usr/local/python2.7/dist-packages目录下 
#++++++++++++++++++++++++++++++++++++++++++++++++++++
rm -rf *.o *.so *.cxx

#用swig自动生成*_wrapper.c文件
swig -c++ -python -shadow DuomiSessionUtil.i

#build_ext仅是测试是否能够成功编译？？？？
#python setup.py build_ext --inplace
#能够一步到位解决所有安装问题:包含了build build_py build_ext install_lib所有步骤 
sudo python setup.py install 
exit 0


#++++++++++++++++++++++++++++++++++++++++++++++++++++
# 以下为使用swig方式编译，仅本目录下可以执行此扩展包 
#++++++++++++++++++++++++++++++++++++++++++++++++++++
rm -rf *.o *.so *.cxx

#用swig自动生成*_wrapper.c文件
swig -c++ -python -shadow DuomiSessionUtil.i

#生成目标文件，为生成动态文件做准备
g++ -fPIC -c DuomiSessionUtil_wrap.cxx \
	-I/usr/local/include/python2.7 \
	-I/usr/local/lib/python2.7/config \
	-L/usr/lib64/libssl

#将.a文件用于生成动态库
gcc -shared DuomiSessionUtil_wrap.o libduomisessionutil.a -o _DuomiSessionUtil.so -lstdc++ -lssl


