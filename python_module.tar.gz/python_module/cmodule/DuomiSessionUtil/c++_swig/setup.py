#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: yemd
# FILENAME: setup.py
# CREATED: 2014-03-13 14:54
# MODIFIED: 2014-02-13 14:54
# Description: 


from distutils.core import setup,Extension
import sys

VERSION = '0.1'


DuomiSessionUtil_module = Extension('_DuomiSessionUtil',  
						include_dirs = ['/usr/include/python2.7',
										'/usr/lib/python2.7/config'],
						libraries = ['duomisessionutil','ssl'],
						library_dirs = ['./','/usr/local/lib'],
                        sources=['DuomiSessionUtil_wrap.cxx'],  
                           )  

setup(name='DuomiSessionUtil',
	  version=VERSION,
      author='DUOMI_PLATFORM',
      author_email='platform@duomi.com',
      url='http://www.duomi.com',
	  download_url='www.duomi.com',
      description='DuomiSessionUtil extend package for duomi_service',
	  license='MIT',
      long_description='',
      ext_modules = [DuomiSessionUtil_module],  
      py_modules = ["DuomiSessionUtil"], 
	  #package_dir=pkgdir,
	  #packages=['DuomiSessionUtil',
	  #			'DuomiSessionUtil.c++_swig'],
	  #package_data={'httplib2': ['*.txt']},
      classifiers=[
        'Development Status :: 1 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries',
        ],
        )
