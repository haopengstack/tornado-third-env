#!/usr/bin//python
#-- coding:utf-8 ----
import sys
import DuomiSessionUtil

print dir(DuomiSessionUtil)

#1.构建类
c = DuomiSessionUtil.SessionChecker()
print c
print type(c)
print dir(c)

