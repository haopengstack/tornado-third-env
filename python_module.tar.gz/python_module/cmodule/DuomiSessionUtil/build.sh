#!/bin/sh


echo "++++++++++++start DuomiSessionUtil Makefile building+++++++++++++"
cd src
make clean
make
cd ..

echo "++++++++++++start DuomiSessionUtil ext_module building++++++++++++"
cd c++_swig
./build.sh
cd ../


