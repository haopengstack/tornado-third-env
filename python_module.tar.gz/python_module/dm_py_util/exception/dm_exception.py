#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: guangling.hou@gmail.com
# FILENAME: dm_exception.py
# CREATED: 2014-02-08 13:43
# MODIFIED: 2014-02-10 11:30
# Description:
class DM_Exception(Exception):
    def __init__(self,value):
        self._value = value
        self._error = ''

    def __str__(self):
        str = repr(self._value)
        if str:
            return self._error + ':' + str
        else:
            return self._error



"""""""""""""""""""""""""""""""""""""""""""""""""""
通用异常定义
"""""""""""""""""""""""""""""""""""""""""""""""""""


"""
会话错误
"""
class DM_SessionError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_SessionError,self).__init__(":".join(value_args))
        self._error = 'SessionError'


"""
输入错误
"""
class DM_InputError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_InputError,self).__init__(":".join(value_args))
        self._error = 'InputError'


"""
内部错误
"""
class DM_InnerError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_InnerError,self).__init__(":".join(value_args))
        self._error = 'InnerError'


"""
请求其他http服务器错误
"""
class DM_HttpRequestError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_HttpRequestError,self).__init__(":".join(value_args))
        self._error = 'HttpRequestError'


"""
redis数据库错误
"""
class DM_RedisError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_RedisError,self).__init__(":".join(value_args))
        self._error = 'RedisError'


"""
mysql数据库错误
"""
class DM_MysqlError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_MysqlError,self).__init__(":".join(value_args))
        self._error = 'MysqlError'


"""""""""""""""""""""""""""""""""""""""""""""""""""
房间业务管理模块自定义异常
"""""""""""""""""""""""""""""""""""""""""""""""""""

"""
房间被禁不允许被激活(即整个房间被拉黑): 激活房间时抛出
"""
class DM_BlackRoomError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_BlackRoomError,self).__init__(":".join(value_args))
        self._error = 'BlackRoomError'

"""
房间不存在: 激活房间时抛出
"""
class DM_RoomNotExistError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_RoomNotExistError,self).__init__(":".join(value_args))
        self._error = 'RoomNotExistError'

"""
存在敏感词: 更改房间信息+聊天
"""
class DM_CensorError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_CensorError,self).__init__(":".join(value_args))
        self._error = 'CensorError'

"""
设置长度超过限制: 更改房间信息
"""
class DM_ExceedLengthError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_ExceedLengthError,self).__init__(":".join(value_args))
        self._error = 'ExceedLengthError'

"""
黑名单用户,即禁止进房间：查询用户能否进入房间
"""
class DM_ForbidEnterError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_ForbidEnterError,self).__init__(":".join(value_args))
        self._error = 'ForbidEnterError'

"""
房间密码错误：查询用户能否进入房间
"""
class DM_PasswordError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_PasswordError,self).__init__(":".join(value_args))
        self._error = 'PasswordError'

"""
房间人数达到人数上限：查询用户能否进入房间
"""
class DM_ExceedRoomLimitError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_ExceedRoomLimitError,self).__init__(":".join(value_args))
        self._error = 'ExceedRoomLimitError'

"""
房间管理员人数达到设置上限：设置管理员时抛出此错误
"""
class DM_ExceedRoomManagerLimitError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_ExceedRoomManagerLimitError,self).__init__(":".join(value_args))
        self._error = 'ExceedRoomManagerLimitError'

"""
黑名单用户(用户被来黑，无法进入任何房间)：设置管理员时抛出此错误
"""
class DM_BlackUserError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_BlackUserError,self).__init__(":".join(value_args))
        self._error = 'BlackUserError'

"""
没有SDJ帐号：设置管理员时抛出此错误
"""
class DM_NotHaveSDJAccountError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_NotHaveSDJAccountError,self).__init__(":".join(value_args))
        self._error = 'NotHaveSDJAccountError'

"""
不是房主，无法设置管理员：设置管理员时抛出此错误
"""
class DM_NotRoomCreatorError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_NotRoomCreatorError,self).__init__(":".join(value_args))
        self._error = 'NotRoomCreatorError'

"""
已经是房间管理员：设置管理员时抛出此错误
"""
class DM_AlreadyRoomManagerError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_AlreadyRoomManagerError,self).__init__(":".join(value_args))
        self._error = 'AlreadyRoomManagerError'

#---------------------以下为新增自定义异常
"""
用户离开房间无法设置：设置管理员时抛出此错误
"""
class DM_UserLeaveRoomError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_UserLeaveRoomError,self).__init__(":".join(value_args))
        self._error = 'UserLeaveRoomError'

"""
账户金币不足：送礼时用户账户金币不足抛出此错误
"""
class DM_MoneyNotEnoughError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_MoneyNotEnoughError,self).__init__(":".join(value_args))
        self._error = 'MoneyNotEnoughError'


"""
礼物会员专属：即用户无送礼权限，此礼物只有ip会员专享
"""
class DM_GiftVIPExclusiveError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_GiftVIPExclusiveError,self).__init__(":".join(value_args))
        self._error = 'GiftVIPExclusiveError'

"""
赠送礼物时未到达足够的活跃等级
"""
class DM_GiftActivityExclusiveError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_GiftActivityExclusiveError,self).__init__(":".join(value_args))
        self._error = 'GiftActivityExclusiveError'



"""
游客重复进入房间：即生成临时游客id时若检测到游客己经进入抛出此异常
"""
class DM_GuestEnterRoomRepeatedError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_GuestEnterRoomRepeatedError,self).__init__(":".join(value_args))
        self._error = 'DM_GuestEnterRoomRepeatedError'


"""
用户当天获取的演唱经验值超过系统限制：即end_sing的时候抛出此异常
"""
class DM_ExceedSystemExpLimitError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_ExceedSystemExpLimitError,self).__init__(":".join(value_args))
        self._error = 'DM_ExceedSystemExpLimitError'



"""
以下为更新房间上下文时抛出的自定义错误
"""
class DM_RoomStatusError(DM_Exception):
    def __init__(self,*value_args):
        super(DM_RoomStatusError,self).__init__(":".join(value_args))
        self._error = 'RoomStatusError'



if __name__ == '__main__':
    try:
        raise DM_HttpRequestError("main_func_name","error")

    except Exception,e:
        print str(e)





