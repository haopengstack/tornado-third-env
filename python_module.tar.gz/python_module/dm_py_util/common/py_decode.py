#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: guangling.hou@gmail.com
# FILENAME: py_decode.py
# CREATED: 2014-02-10 13:22
# MODIFIED: 2014-04-11 09:57
# Description: 


import chardet
import struct


class PY_Decode():
	def decode(self,data):
		back = None
		try:
			#codec_info = chardet.detect(data)
			#print 'codec_info',codec_info
			back = data.decode('utf-8')	
		except Exception,e:
			print 'Exception,%s',str(e)
			back = unicode(data, errors='ignore')
		return back



if __name__ == '__main__':
	s = struct.pack('=IB', 1021231, 123) 
	print s
	decoder = PY_Decode()
	print decoder.decode(s)

	print decoder.decode('ddd')
	print decoder.decode('你好')
		
	print decoder.decode(10)
