#!/usr/bin/python
#-*- coding: utf-8 -*-
# AUTHOR: guangling.hou@gmail.com
# FILENAME: py_config.py
# CREATED: 2013-04-07 15:50
# MODIFIED: 2013-04-07 18:51
# Description: 

import ConfigParser

class PYC_ConfigParser():
	def __init__(self,cfgfile):
		self._configfile = cfgfile
		config = ConfigParser.ConfigParser()
		with open(cfgfile,'rw') as filefd:  
			config.readfp(filefd)  
		self._allconfig = {}
		for section in config.sections():
			self._allconfig[section] = self._init_config(config,section)

	def _init_config(self,config,section):
		back_config = {}
		if not config.has_section(section):
			return None
		for option in config.options(section):
			back_config[option] = config.get(section,option)
		return back_config

	def get_configs(self,section):
		if self._allconfig.has_key(section):
			return self._allconfig[section]
		return None

	def get_config(self,section,name):
		if self._allconfig.has_key(section):
			config = self._allconfig[section]
			if config.has_key(name):
				return config[name]
		return None

