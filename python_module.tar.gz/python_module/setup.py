#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: peng.hao@gmail.com
# FILENAME: setup.py
# CREATED: 2015-02-10 15:44
# MODIFIED: 2015-02-11 13:54
# Description: 


try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup
import sys

VERSION = '0.1'

setup(name='dm_py_util',
	  version=VERSION,
      author='DUOMI_PLATFORM',
      author_email='platform@duomi.com',
      url='http://www.duomi.com',
	  download_url='www.duomi.com',
      description='',
	  license='MIT',
      long_description='',
	  #package_dir=pkgdir,
	  packages=['dm_py_util',
				'dm_py_util.common',
				'dm_py_util.exception',
				'dm_py_util.store'],
	  #package_data={'httplib2': ['*.txt']},
      classifiers=[
        'Development Status :: 1 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries',
        ],
        )
