#!/usr/bin/env python
#-*- coding: utf-8 -*-
# AUTHOR: guangling.hou@gmail.com
# FILENAME: singleton.py
# CREATED: 2014-03-18 21:31
# MODIFIED: 2014-04-17 08:01
# Description:

import sys

def singleton(Class_):
    instances = {}
    def getinstance(*args,**kwargs):
        if Class_ not in instances:
            try:
                instances[Class_] = Class_(*args,**kwargs)
            except:
                instances.pop(Class_,None)
                return None
        return instances[Class_]
    return getinstance
