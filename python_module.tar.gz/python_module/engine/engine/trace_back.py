import inspect
import traceback

def filename():
    return inspect.currentframe().f_back.f_code.co_filename

def fileno():
    return inspect.currentframe().f_back.f_lineno

def coname():
    return inspect.currentframe().f_back.f_code.co_name

def fn():
    fr = inspect.currentframe()
    return ','.join([str(x) for x in [fr.f_back.f_code.co_filename, 
                     fr.f_back.f_code.co_name, fr.f_back.f_lineno], traceback.format_exc()])


if __name__ == '__main__':
    def foo():
        print fileno()
    def bar():
        print filename()
    def zoo():
        print coname()
    def zar():
        try:
            raise Exception('ll;;;')
        except:
	    print fn()
    import time
    e_time = time.time()
    #foo()
    #bar()
    #zoo()
    zar()
    print (time.time() - e_time) * 1000
