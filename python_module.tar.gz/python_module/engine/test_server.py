#!/usr/bin/env python
# -*- coding: utf-8 -*-

from tornado import gen
from engine import BaseHandler, BaseHTTPServer


class HelloWorldHandler(BaseHandler):
    @gen.coroutine
    def process(self):
        return {'resp': 'HelloWorld'}

from engine import BaseHTTPServer
s = BaseHTTPServer(HelloWorldHandler)
s.init('/a8root/conf/live_business/server.ini')
s.serve_forever(False)
