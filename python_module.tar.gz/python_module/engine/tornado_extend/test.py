#!/usr/bin/env python
# -*- coding: utf-8 -*-

from tornado_extend import HTTPServer, HTTPWorker
from dm_py_util import DEBUG_LOG

class TestServer(HTTPServer):
    def install_handler(self):
        from tornado import gen
        from engine import BaseHandler
        # class HelloWorld(BaseHandler):
        #     def process(self):
        #         return {'dm_error':0, 'error_msg': 0}
        class HelloWorld(BaseHandler):
            @gen.coroutine
            def get(self):
                self.redirect('http://www.baidu.com')
                # return {'dm_error':0, 'error_msg': 0}
        return [HelloWorld]

class TestWorker(HTTPWorker):
    def init_worker(self, config):
        super(TestWorker, self).init_worker(config)

        from extend import set_timeout, set_interval
        def interval_event(*args, **kw):
            DEBUG_LOG('interval event', args, kw)
        def timeout_event(*args, **kw):
            DEBUG_LOG('timeout event', args, kw)
        set_interval(interval_event, 1000, 2, 3, 4, a=2, b=3)
        set_timeout(timeout_event, 1000, 2, 3, 4, a=2000, b=3)



if __name__ == '__main__':
    s = TestServer(main_config='./conf/master.config', worker=TestWorker)
    DEBUG_LOG('TestWorker start......')
    s.run()
