#!/usr/bin/env python
# -*- coding: utf-8 -*-


import tornado.ioloop
from extend import timeout_run, set_timeout, set_interval
import datetime

# @timeout_run(2000)
def test():
    print 'test.....run', datetime.datetime.now()

# @timeout_run(1000)
def test2():
    print 'test.....run 2', datetime.datetime.now()

set_timeout(test, 1000)
set_interval(test2, 2000)
print datetime.datetime.now()
tornado.ioloop.IOLoop.current().start()
