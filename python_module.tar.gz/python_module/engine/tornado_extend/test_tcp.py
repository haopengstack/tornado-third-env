#!/usr/bin/env python
# -*- coding: utf-8 -*-

from tornado.iostream import IOStream
from tcpserver import TCPHandler, TCPWorker, Server, Connection
from dm_py_util import DEBUG_LOG

class TestConnection(Connection):
    def on_arrived(self):
        super(TestConnection, self).on_arrived()
        self.process()

    def process(self):
        self.stream.read_bytes(4, self.on_header)

    def on_header(self, header):
        DEBUG_LOG('header....', header)
        self.process()
        # body_len = int(header)
        # self.stream.read_bytes(body_len, self.on_body)

    def on_body(self, body):
        DEBUG_LOG('body...', body)
        self.process()


class TestHandler(TCPHandler):
    def handle_stream(self, stream, address):
        c = TestConnection(stream, address)

class TestWorker(TCPWorker):
    def start(self):
        from subclient import SubscribeClient
        # s = SubscribeClient(('192.168.20.125', 6045), 'cluster_0')
        # from extend import set_timeout, set_interval
        # def interval_event(*args, **kw):
        #     DEBUG_LOG('interval event', args, kw)
        # def timeout_event(*args, **kw):
        #     DEBUG_LOG('timeout event', args, kw)
        # set_interval(interval_event, 1000, 2, 3, 4, a=2, b=3)
        # set_timeout(timeout_event, 1000, 2, 3, 4, a=2000, b=3)

s = Server(main_config='./conf/tcp.ini', worker=TestWorker, handler=TestHandler)
s.run()
