#!/usr/bin/env python
# -*- coding: utf-8 -*-

from sql_manager import SQLManager
m = SQLManager()
