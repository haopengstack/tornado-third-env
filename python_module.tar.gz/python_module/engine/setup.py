#!/usr/bin/env python
#-*- coding: utf-8 -*-
from setuptools import setup, find_packages

try:
    from setuptools import setup
except ImportError:
    from distutils.core import setup
import sys

VERSION = '0.1'

setup(name='engine',
	  version=VERSION,
      author='DUOMI_PLATFORM',
      author_email='platform@duomi.com',
      url='http://www.test.com',
	  download_url='www.test.com',
      description='',
	  license='MIT',
      long_description='',
      #package_dir=pkgdir,
      # packages=['engine', 'tornado_extend'],
      #package_data={'httplib2': ['*.txt']},
      classifiers=[
        'Development Status :: 1 - Beta',
        'Environment :: Web Environment',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2',
        'Topic :: Internet :: WWW/HTTP',
        'Topic :: Software Development :: Libraries',
        ],
      # keyword = 'tornado multiprocess',
      install_requires=[
          'tornado',
          ],
      packages=find_packages(),
      include_package_data=True
        )
