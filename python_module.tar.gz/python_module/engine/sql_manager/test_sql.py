#!/usr/bin/env python
# -*- coding: utf-8 -*-


from client import SQLClient


m = SQLClient('127.0.0.1', 3306, 'test', 'hou', 'a')
ret = m.query('select * from update_user')
print ret
# m.insert('insert into users (uid, name) value (%s, %s)', 123232, '哈哈')


with m.transation() as trans:
    print trans
    trans.begin()
    try:
        trans.executemany('insert into users (uid , name) value (%s, %s)', ((12323, '哈哈'), (1232322, '哈哈')))
        # print trans.insert('insert into users (uid, name) value (%s, %s)', 123232, '哈哈')
        # trans.execute('insert into users (uid, name) value (%s, %s)', 12323, '哈哈')
        # print trans.update('update users set uid = %s where uid = 12323', 12332323)
        # raise Exception('test....')
    except Exception as e:
        print 'error...', e
        trans.rollback()
    else:
        trans.commit()
print m.executemany_rowcount('update users set name = %s', '哈哈哈232323')
print m.execute('update users set name = %s', '哈哈哈232323')
