#!/usr/bin/env python
# -*- coding: utf-8 -*-

from connection import Connection, ConnectionPool


try:
    con = Connection(host='127.0.0.1', port=3306, database='client_log', user='hou', password='a', max_idle_time=10 * 10, connect_timeout=0)
    print con
except Exception as e:
    print 'Error', e

p = ConnectionPool(Connection, 2, host='127.0.0.1', port=3306, database='client_log', user='hou', password='a', max_idle_time=10 * 10, connect_timeout=0)
conn = p.get_connection()
print conn
conn = p.get_connection()
print conn
conn = p.get_connection()
print conn
conn = p.get_connection()
print conn
conn = p.get_connection()
print conn
conn = p.get_connection()
print conn
