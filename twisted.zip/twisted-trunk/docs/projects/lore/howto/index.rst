
:LastChangedDate: $LastChangedDate$
:LastChangedRevision: $LastChangedRevision$
:LastChangedBy: $LastChangedBy$

Developer Guides
================


.. toctree::
   :hidden:

   lore
   extend-lore






- :doc:`Lore documentation system <lore>`
- :doc:`Extending Lore <extend-lore>`



