
:LastChangedDate: $LastChangedDate$
:LastChangedRevision: $LastChangedRevision$
:LastChangedBy: $LastChangedBy$

Twisted Mail
============


.. toctree::
   :hidden:

   examples/index
   tutorial/smtpclient/smtpclient





- :doc:`Examples <examples/index>` : short code examples using
  Twisted Mail
- :doc:`Twisted Mail Tutorial <tutorial/smtpclient/smtpclient>` : Building
  an SMTP Client from Scratch




